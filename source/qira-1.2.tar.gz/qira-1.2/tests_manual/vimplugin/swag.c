void swag() {
  printf("SWAG!\n");
}

void swag2() {
  printf("SWAG2!\n");
}

