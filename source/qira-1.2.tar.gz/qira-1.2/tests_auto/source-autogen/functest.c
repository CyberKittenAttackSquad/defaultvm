int a() {
  return 27;
}

int b() {
  return 52;
}

int main() {
  int i = a() + b();
  if (i > 0) {
    printf("%d\n", i);
  } else {
    printf("TEH FUCK\n");
  }
  return 0;
}

