int main() {
  printf("hello %p\n", main);
}

