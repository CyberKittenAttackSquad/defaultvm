#!/bin/sh
gdb /home/vagrant/idademo66/python -ex "r trial.py"

